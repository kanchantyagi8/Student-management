// export class StudentModel {
//     age: number;
//     class: number;
//     gender: string;
//     name: string;
//     rollNumber: string;
//     section: string;
//     sports: string[];
// }

export class StudentModel {
    
}
