import { Component, OnInit } from '@angular/core';
import { StudentService } from '../../services/student.service';
import { StudentModel } from '../../models/student.model';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  studentsModel;
  studentData: any = [];
  studentContainer: Array<any> = [];
  classes: Array<number> = [1,2,3,4,5,6,7,,8,9,10,11,12];
  studentDetails: any;
  studentInfo: any = {};
  showSidebar: boolean = false;

  constructor(private studentService: StudentService) { }

  ngOnInit(): void {
    this.getStudentData();
  }

  getStudentData() {
    this.studentService.getStudentClass().subscribe(
      (response) => {
        this.studentsModel = response;
        this.classes.forEach(classEle => {
          let arr = [];
          this.studentsModel.forEach(element => {
            if(element.class === classEle) {
              arr.push(element);
            }
          });
          this.studentContainer.push(arr);
          arr = [];
        });
        console.log(this.studentContainer);
      },
      (error) => {
        console.log("Error: ", error);
      }
    )
  }

  showStudentData(studentRollNumber) {
    this.studentsModel.filter((element) => {
      if(element.rollNumber === studentRollNumber) {
        this.studentData = element;
      }
    });
    this.showSidebar = true;
    this.studentDetails = this.studentData;
  }

  showTooltipData(id) {
    this.studentsModel.filter((element) => {
      if(element.rollNumber === id) {
        this.studentInfo = element;
      }
    });
    this.studentInfo;
  }

  close() {
    this.showSidebar = false;
  }
  
}
